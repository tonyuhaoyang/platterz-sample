package com.tabtech.project.controller;

import com.tabtech.project.model.PublicLot;
import com.tabtech.project.service.PublicLotService;
import com.tabtech.project.util.CustomErrorType;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.util.UriComponentsBuilder;

import java.sql.Timestamp;
import java.util.List;

/**
 * Created by tonyy on 4/29/2017.
 */
@RestController
@RequestMapping("/api")
public class RestApiLotController {
    public static final Logger logger = LoggerFactory.getLogger(RestApiLotController.class);

    @Autowired
    PublicLotService plService; // Service that interacts with the repository to grab data from the model

    //gets a public lot entity of a given id
    @RequestMapping(value = "/lot/{id}", method = RequestMethod.GET)
    public ResponseEntity<?> get(@PathVariable("id") Integer id) {
        logger.info("Fetching lot with id {}", id);
        PublicLot publicLot = plService.findById(id);
        if (publicLot == null) {
            logger.error("Lot with id {} not found.", id);
            return new ResponseEntity(new CustomErrorType("Lot with id " + id
                    + " not found"), HttpStatus.NOT_FOUND);
        }
        return new ResponseEntity<PublicLot>(publicLot, HttpStatus.OK);
    }

    //gets all public lot entities
    @RequestMapping(value = "/lot/", method = RequestMethod.GET)
    public ResponseEntity<List<PublicLot>> listAll(){
        List<PublicLot> publicLots = plService.findAll();
        if (publicLots.isEmpty()){
            return new ResponseEntity(HttpStatus.NO_CONTENT);
        }
        return new ResponseEntity<List<PublicLot>>(publicLots, HttpStatus.OK);
    }

    //adds a public lot entity to the data model
    @RequestMapping(value = "/lot/", method = RequestMethod.POST)
    public ResponseEntity<?> create(@RequestBody PublicLot lot, UriComponentsBuilder ucBuilder) {

        logger.info("Creating public lot with location : {}", lot.getLocation());
        if (plService.isExist(lot)) {
            logger.error("Unable to create. A lot with location {} already exists", lot.getLocation());
            return new ResponseEntity(new CustomErrorType("Unable to create. A lot with location " +
                   lot.getLocation() + " already exists."),HttpStatus.CONFLICT);
        }
        lot.setCreateTimestamp(new Timestamp(System.currentTimeMillis()));
        lot.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

        plService.save(lot);
        HttpHeaders headers = new HttpHeaders();
        headers.setLocation(ucBuilder.path("/api/lot/{id}").buildAndExpand(lot.getId()).toUri());
        return new ResponseEntity<String>(headers, HttpStatus.CREATED);
    }

    //updates a public lot entity
    @RequestMapping(value = "/lot/{id}", method = RequestMethod.PUT)
    public ResponseEntity<?> update(@PathVariable("id") Integer id, @RequestBody PublicLot lot) {

        logger.info("Updating lot with location {}", lot.getLocation());
        PublicLot currentLot = plService.findById(id);
        if (currentLot == null) {
            logger.error("Unable to update. Lot not found.", id);
            return new ResponseEntity(new CustomErrorType("Unable to upate. Lot not found."),
                    HttpStatus.NOT_FOUND);
        }
        currentLot.setLocation(lot.getLocation());
        currentLot.setLocationCoordinate(lot.getLocationCoordinate());
        currentLot.setDescription(lot.getDescription());
        currentLot.setUpdateTimestamp(new Timestamp(System.currentTimeMillis()));

        plService.save(currentLot);
        return new ResponseEntity<PublicLot>(currentLot, HttpStatus.OK);
    }

    //deletes a public lot entity
    @RequestMapping(value = "/lot/{id}", method = RequestMethod.DELETE)
    public ResponseEntity<?> delete(@PathVariable("id") Integer id) {

        logger.info("Deleting public lot with id {}", id);
        PublicLot lot = plService.findById(id);
        if (lot == null) {
            logger.error("Unable to delete. Lot not found.");
            return new ResponseEntity(new CustomErrorType("Unable to delete. Lot not found."),
                    HttpStatus.NOT_FOUND);
        }

        plService.deleteById(id);
        return new ResponseEntity<PublicLot>(HttpStatus.NO_CONTENT);
    }

    //delete all public lot entities
    @RequestMapping(value = "/lot/", method = RequestMethod.DELETE)
    public ResponseEntity<PublicLot> deleteAll() {

        logger.info("Deleting all public lots ");

        plService.deleteAll();
        return new ResponseEntity<PublicLot>(HttpStatus.NO_CONTENT);
    }




}
