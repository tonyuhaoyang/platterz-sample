package com.tabtech.project.model;

import org.hibernate.validator.constraints.NotEmpty;

import javax.persistence.*;
import java.io.Serializable;
import java.sql.Timestamp;

/**
 * Created by tonyy on 4/29/2017.
 */


@Entity
@Table(name="public_lot")
public class PublicLot implements Serializable{
    @Id
    @GeneratedValue(strategy= GenerationType.IDENTITY)
    private Integer id;

    @Column(name="location", nullable=false, unique = true)
    private String location;

    @Column(name="location_coordinate")
    private String locationCoordinate;

    @Column(name="description")
    private String description;

    @Column(name="create_timestamp", nullable=false)
    private Timestamp createTimestamp;

    @Column(name="update_timestamp", nullable=false)
    private Timestamp updateTimestamp;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getLocationCoordinate() {
        return locationCoordinate;
    }

    public void setLocationCoordinate(String locationCoordinate) {
        this.locationCoordinate = locationCoordinate;
    }

    public Timestamp getCreateTimestamp() {
        return createTimestamp;
    }

    public void setCreateTimestamp(Timestamp createTimestamp) {
        this.createTimestamp = createTimestamp;
    }

    public Timestamp getUpdateTimestamp() {
        return updateTimestamp;
    }

    public void setUpdateTimestamp(Timestamp updateTimestamp) {
        this.updateTimestamp = updateTimestamp;
    }

    @Override
    public String toString() {
        return "PublicLot{" +
                "id=" + id +
                ", location='" + location + '\'' +
                ", locationCoordinate='" + locationCoordinate + '\'' +
                ", description='" + description + '\'' +
                ", createTimestamp=" + createTimestamp +
                ", updateTimestamp=" + updateTimestamp +
                '}';
    }

}
