package com.tabtech.project.repository;

import com.tabtech.project.model.PublicLot;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

/**
 * Created by tonyy on 4/29/2017.
 */
@Repository
public interface PublicLotRepository extends JpaRepository<PublicLot, Integer>{
    PublicLot findByLocation(String location);
}
