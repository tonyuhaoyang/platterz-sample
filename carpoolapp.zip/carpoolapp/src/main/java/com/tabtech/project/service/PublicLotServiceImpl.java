package com.tabtech.project.service;

import com.tabtech.project.model.PublicLot;
import com.tabtech.project.repository.PublicLotRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import javax.transaction.Transactional;
import java.util.List;

/**
 * Created by tonyy on 4/29/2017.
 */

@Service("publicLotService")
@Transactional
public class PublicLotServiceImpl implements PublicLotService{
    @Autowired
    private PublicLotRepository plRepository;

    public PublicLot findById(Integer id){
        return plRepository.findOne(id);
    }

    public PublicLot findByLocation(String location) { return plRepository.findByLocation(location);}

    public List<PublicLot> findAll(){return plRepository.findAll();}

    public boolean isExist(PublicLot lot) {
        return findByLocation(lot.getLocation()) != null;
    }

    public void save(PublicLot lot){
        plRepository.save(lot);
    }

    public void deleteById(Integer id) {
        plRepository.delete(id);
    }

    public void deleteAll() {
        plRepository.deleteAll();
    }
}
