package com.tabtech.project.service;

import com.tabtech.project.model.PublicLot;

import java.util.List;

/**
 * Created by tonyy on 4/29/2017.
 */
public interface PublicLotService {
    PublicLot findById(Integer id);

    void save(PublicLot lot);

    void deleteById(Integer id);

    void deleteAll();

    boolean isExist(PublicLot lot);

    List<PublicLot> findAll();

    public PublicLot findByLocation(String location);
}
