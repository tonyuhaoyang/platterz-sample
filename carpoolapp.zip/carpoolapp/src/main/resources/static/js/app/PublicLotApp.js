var app = angular.module('crudApp',['ui.router','ngStorage']);

app.constant('urls', {
    BASE: 'http://localhost:8080/carpoolapp',
    SERVICE_API : 'http://localhost:8080/carpoolapp/api/'
});

app.config(['$stateProvider', '$urlRouterProvider',
    function($stateProvider, $urlRouterProvider) {

        $stateProvider
            .state('home', {
                url: '/',
                templateUrl: '/carpoolapp/partials/publicLotList',
                controller:'PublicLotController',
                controllerAs:'ctrl',
                resolve: {
                    publicLots: function ($q, PublicLotService) {
                        console.log('Loading all lots');
                        var deferred = $q.defer();
                        PublicLotService.loadAllLots().then(deferred.resolve, deferred.resolve);
                        return deferred.promise;
                    }
                }
            });
        $urlRouterProvider.otherwise('/');
    }]);

