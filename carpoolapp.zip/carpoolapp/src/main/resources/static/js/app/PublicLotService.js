'use strict';

angular.module('crudApp').factory('PublicLotService',
    ['$localStorage', '$http', '$q', 'urls',
        function ($localStorage, $http, $q, urls) {

            var factory = {
                loadAllLots: loadAllLots,
                getAllLots: getAllLots,
                getLot: getLot,
                createLot: createLot,
                updateLot: updateLot,
                removeLot: removeLot
            };

            return factory;

            function loadAllLots() {
                console.log('Fetching all lots');
                var deferred = $q.defer();
                $http.get(urls.SERVICE_API+"lot/")
                    .then(
                        function (response) {
                            console.log('Fetched successfully all lots');
                            $localStorage.lots = response.data;
                            deferred.resolve(response);
                        },
                        function (errResponse) {
                            console.error('Error while loading lots');
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function getAllLots(){
                return $localStorage.lots;
            }

            function getLot(id) {
                console.log('Fetching Lot with id :'+id);
                var deferred = $q.defer();
                $http.get(urls.SERVICE_API + "lot/" + id)
                    .then(
                        function (response) {
                            console.log('Fetched successfully lot with id:'+id);
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while loading lot with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function createLot(lot) {
                console.log('Creating lot');
                var deferred = $q.defer();
                $http.post(urls.SERVICE_API + "lot/", lot)
                    .then(
                        function (response) {
                            loadAllLots();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                           console.error('Error while creating lot : '+errResponse.data.errorMessage);
                           deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function updateLot(lot, id) {
                console.log('Updating Lot with id '+id);
                var deferred = $q.defer();
                $http.put(urls.SERVICE_API + "lot/" + id, lot)
                    .then(
                        function (response) {
                            loadAllLots();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while updating Lot with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

            function removeLot(id) {
                console.log('Removing Lot with id '+id);
                var deferred = $q.defer();
                $http.delete(urls.SERVICE_API + "lot/" + id)
                    .then(
                        function (response) {
                            loadAllLots();
                            deferred.resolve(response.data);
                        },
                        function (errResponse) {
                            console.error('Error while removing lot with id :'+id);
                            deferred.reject(errResponse);
                        }
                    );
                return deferred.promise;
            }

        }
    ]);