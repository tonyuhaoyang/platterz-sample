'use strict';

angular.module('crudApp').controller('PublicLotController',
    ['PublicLotService', '$scope',  function( PublicLotService, $scope) {

        var self = this;
        self.lot = {};
        self.lots=[];

        self.submit = submit;
        self.getAllLots = getAllLots;
        self.createLot = createLot;
        self.updateLot = updateLot;
        self.removeLot = removeLot;
        self.editLot = editLot;
        self.reset = reset;

        self.successMessage = '';
        self.errorMessage = '';
        self.done = false;

        self.onlyIntegers = /^\d+$/;
        self.onlyNumbers = /^\d+([,.]\d+)?$/;

        function submit() {
            console.log('Submitting');
            console.log(self.lot.id);
            if (self.lot.id === undefined || self.lot.id === null) {
                console.log('Saving New Lot', self.lot);
                createLot(self.lot);
            } else {
                updateLot(self.lot, self.lot.id);
                console.log('Lot updated with id ', self.lot.id);
                self.lot = {};
            }
        }

        function createLot(lot) {
            console.log('About to create lot');
            PublicLotService.createLot(lot)
                .then(
                    function (response) {
                        console.log('Lot created successfully');
                        self.successMessage = 'Lot created successfully';
                        self.errorMessage='';
                        self.done = true;
                        self.lot={};
                        $scope.myForm.$setPristine();
                    },
                    function (errResponse) {
                        console.error('Error while creating Lot');
                        self.errorMessage = 'Error while creating Lot: ' + errResponse.data.errorMessage;
                        self.successMessage='';
                    }
                );
        }


        function updateLot(lot, id){
            console.log('About to update Lot');
            PublicLotService.updateLot(lot, id)
                .then(
                    function (response){
                        console.log('Lot updated successfully');
                        self.successMessage='Lot updated successfully';
                        self.errorMessage='';
                        self.done = true;
                        $scope.myForm.$setPristine();
                    },
                    function(errResponse){
                        console.error('Error while updating Lot');
                        self.errorMessage='Error while updating Lot '+errResponse.data;
                        self.successMessage='';
                    }
                );
        }


        function removeLot(id){
            console.log('About to remove public with id '+id);
            PublicLotService.removeLot(id)
                .then(
                    function(){
                        console.log('Public lot '+id + ' removed successfully');
                    },
                    function(errResponse){
                        console.error('Error while removing public lot '+id +', Error :'+errResponse.data);
                    }
                );
        }


        function getAllLots(){
            return PublicLotService.getAllLots();
        }

        function editLot(id) {
            self.successMessage='';
            self.errorMessage='';
            PublicLotService.getLot(id).then(
                function (lot) {
                    self.lot = lot;
                    console.log(self.lot.id);
                },
                function (errResponse) {
                    console.error('Error while removing public lot ' + id + ', Error :' + errResponse.data);
                }
            );
        }
        function reset(){
            self.successMessage='';
            self.errorMessage='';
            self.lot={};
            $scope.myForm.$setPristine(); //reset Form
        }
    }


    ]);